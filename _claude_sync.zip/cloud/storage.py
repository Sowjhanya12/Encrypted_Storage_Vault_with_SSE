"""
cloud/storage.py -- SQLite access layer for the untrusted cloud store.

Everything in this file runs on the UNTRUSTED side of the trust
boundary (Section 02 of docs/architecture.html). It holds zero keys
and never imports anything from client/ -- nothing here needs a key or
a tokenizer to store and retrieve bytes.

This module treats every value it is given as an opaque byte string.
It has no idea whether "ciphertext" is really AES-GCM output, whether
"label" is really an HMAC digest, or what any of it decrypts to -- and
it must never need to know. That is exactly what makes the
"honest-but-curious cloud" argument (Section 09) hold: even a fully
inspected copy of vault.sqlite3 has nothing in it for the cloud
operator to read.

Schema (Section 08) -- three tables, all untrusted:

  documents   doc_id (PK), enc_name, nonce, ciphertext, tag,
              size, uploaded_at
  sse_index   label (PK), value
  meta        key (PK), value
"""

from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterable, Iterator, Optional

_SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    doc_id      TEXT PRIMARY KEY,
    enc_name    BLOB NOT NULL,
    nonce       BLOB NOT NULL,
    ciphertext  BLOB NOT NULL,
    tag         BLOB NOT NULL,
    size        INTEGER NOT NULL,
    uploaded_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

CREATE TABLE IF NOT EXISTS sse_index (
    label TEXT PRIMARY KEY,
    value BLOB NOT NULL
);

CREATE TABLE IF NOT EXISTS meta (
    key   TEXT PRIMARY KEY,
    value BLOB NOT NULL
);
"""


def connect(db_path: "str | Path") -> sqlite3.Connection:
    """Open (creating if needed) the cloud's SQLite store and make sure
    the schema exists. One connection per request/test is fine --
    SQLite handles that cheaply and it keeps this module stateless."""
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.executescript(_SCHEMA)
    conn.commit()
    return conn


@contextmanager
def open_db(db_path: "str | Path") -> Iterator[sqlite3.Connection]:
    """Context-manager convenience: `with open_db(path) as conn: ...`
    commits on clean exit and always closes the connection, even if
    the caller raises."""
    conn = connect(db_path)
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


class DuplicateDocumentError(Exception):
    """Raised when a doc_id already exists. IDs are assigned by the
    trusted client (Section 07, flow B: "Assign a random doc_id") --
    a collision here means a client bug or a bad-faith re-upload, not
    routine data storage.py should silently overwrite."""


class DocumentNotFoundError(Exception):
    pass


# ---------------------------------------------------------------------------
# documents
# ---------------------------------------------------------------------------

def save_document(
    conn: sqlite3.Connection,
    doc_id: str,
    enc_name: bytes,
    nonce: bytes,
    ciphertext: bytes,
    tag: bytes,
) -> None:
    """Store one encrypted document.

    `size` is deliberately NOT a parameter: it is always computed here
    as len(ciphertext) rather than trusted from a caller-supplied
    value, so it can never drift from the bytes actually stored.
    """
    try:
        conn.execute(
            """
            INSERT INTO documents (doc_id, enc_name, nonce, ciphertext, tag, size)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (doc_id, enc_name, nonce, ciphertext, tag, len(ciphertext)),
        )
    except sqlite3.IntegrityError as exc:
        raise DuplicateDocumentError(f"doc_id {doc_id!r} already exists") from exc


def get_document(conn: sqlite3.Connection, doc_id: str) -> dict:
    row = conn.execute("SELECT * FROM documents WHERE doc_id = ?", (doc_id,)).fetchone()
    if row is None:
        raise DocumentNotFoundError(f"no document with doc_id {doc_id!r}")
    return dict(row)


def list_documents(conn: sqlite3.Connection) -> "list[dict]":
    """Metadata only -- no ciphertext body. This is what a future
    'vault list' screen pages through. enc_name is still the encrypted
    bytes; nothing returned here is plaintext."""
    rows = conn.execute(
        "SELECT doc_id, enc_name, size, uploaded_at FROM documents ORDER BY uploaded_at"
    ).fetchall()
    return [dict(r) for r in rows]


def document_count(conn: sqlite3.Connection) -> int:
    return conn.execute("SELECT COUNT(*) FROM documents").fetchone()[0]


def replace_document(
    conn: sqlite3.Connection,
    doc_id: str,
    enc_name: bytes,
    nonce: bytes,
    ciphertext: bytes,
    tag: bytes,
) -> bool:
    """Overwrite an EXISTING document's encrypted fields in place,
    under the same doc_id -- added for password/key rotation
    (client_app.py's api_change_password), which must re-encrypt every
    document under a new K_file without changing which doc_id it is
    stored under (search-index labels/values reference doc_id, not the
    ciphertext, so the doc_id itself must be stable across a rotation).

    Deliberately a separate function from save_document(), not a
    save_document() that upserts: save_document()'s INSERT-only
    behaviour (raising DuplicateDocumentError on a collision) is a
    correctness property Phase 2 relies on -- a doc_id collision on
    ordinary upload is assign a random doc_id gone catastrophically
    wrong, not routine data storage.py should silently allow. Rotation
    needs the opposite guarantee (the row must already exist), so it
    gets its own explicit primitive rather than blurring that one.

    `size` is recomputed from the new ciphertext, exactly like
    save_document() -- it must reflect what is actually stored, not a
    stale value from before rotation.

    Returns True if a row existed and was updated, False if doc_id was
    not found (the caller decides whether that is an error -- rotation
    treats it as one, since every doc_id it processes came from its own
    fresh list_documents() call moments earlier).
    """
    cur = conn.execute(
        """
        UPDATE documents
        SET enc_name = ?, nonce = ?, ciphertext = ?, tag = ?, size = ?
        WHERE doc_id = ?
        """,
        (enc_name, nonce, ciphertext, tag, len(ciphertext), doc_id),
    )
    return cur.rowcount > 0


def delete_document(conn: sqlite3.Connection, doc_id: str) -> bool:
    """Delete one document row. Returns True if a row existed and was
    removed, False if doc_id was not found -- an ordinary, expected
    outcome (not every delete follows a successful lookup, e.g. a
    concurrent request), so this layer reports it as a plain bool
    rather than raising DocumentNotFoundError; the caller (cloud_app.py)
    decides whether "not found" becomes a 404."""
    cur = conn.execute("DELETE FROM documents WHERE doc_id = ?", (doc_id,))
    return cur.rowcount > 0


# ---------------------------------------------------------------------------
# sse_index
# ---------------------------------------------------------------------------

def save_index_entries(conn: sqlite3.Connection, entries: "Iterable[tuple[str, bytes]]") -> int:
    """Bulk-insert (label, value) rows into the flat Pi_bas dictionary D
    (Section 05). Takes an iterable so a later indexer.py can push an
    entire keyword's postings list in one call. Returns the row count
    inserted.

    A label collision is a genuine anomaly (labels are HMAC outputs --
    a real collision means a serious bug upstream), so it is left to
    propagate as sqlite3.IntegrityError rather than silently
    overwritten or swallowed here.
    """
    entries = list(entries)
    conn.executemany("INSERT INTO sse_index (label, value) VALUES (?, ?)", entries)
    return len(entries)


def get_index_entry(conn: sqlite3.Connection, label: str) -> "Optional[bytes]":
    """Single-label lookup: does D contain this label, and if so what
    opaque value sits under it?

    This is a raw storage primitive only -- it does NOT iterate
    counters or implement the Pi_bas search loop from Section 06. That
    loop (repeatedly deriving F(K1, counter) and calling this once per
    counter until a miss) is Phase 4's job; this function is the one
    building block it will call.
    """
    row = conn.execute("SELECT value FROM sse_index WHERE label = ?", (label,)).fetchone()
    return row["value"] if row is not None else None


def index_entry_count(conn: sqlite3.Connection) -> int:
    """Total (keyword, document) pairs currently indexed -- exactly the
    'setup size' leakage the architecture doc names in Section 09."""
    return conn.execute("SELECT COUNT(*) FROM sse_index").fetchone()[0]


def clear_index(conn: sqlite3.Connection) -> int:
    """Delete every row from sse_index. Returns the number removed.

    Added in Phase 5 for a concrete reason, not speculatively: this
    project's index is a static, from-scratch rebuild (Section 10 --
    adding a document means rebuilding the whole index, not patching
    it). build_index() assigns postings counters in doc_id-sorted
    order, so adding a new document can shift which counter an
    EXISTING document receives for a keyword they both share, which
    changes that document's label. Re-pushing a rebuilt index
    additively (via save_index_entries alone) would therefore leave
    the old, now-orphaned rows from the previous counter assignment
    sitting in the table alongside the new ones. Rebuilding correctly
    means replacing the whole table atomically -- clear_index() is
    that clear step; cloud_app.py's POST /index/replace calls it
    immediately before save_index_entries() within the same
    transaction.
    """
    cur = conn.execute("DELETE FROM sse_index")
    return cur.rowcount


# ---------------------------------------------------------------------------
# meta
# ---------------------------------------------------------------------------

def set_meta(conn: sqlite3.Connection, key: str, value: bytes) -> None:
    """Upsert one non-secret setup parameter (KDF salt, Argon2 cost
    params, scheme version -- Section 08). Stored in plaintext by
    design: these values are not secret, only the password that
    combines with the salt is."""
    conn.execute(
        "INSERT INTO meta (key, value) VALUES (?, ?) "
        "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        (key, value),
    )


def get_meta(conn: sqlite3.Connection, key: str) -> "Optional[bytes]":
    row = conn.execute("SELECT value FROM meta WHERE key = ?", (key,)).fetchone()
    return row["value"] if row is not None else None

"""
cloud/cloud_app.py -- Flask app for the untrusted cloud service.

This is a separate process from the (future) trusted client app,
listening on its own port, so the client/cloud split described in
Section 02 is a genuine process boundary -- not just two functions in
one script. That separation is what lets the demo open this app's
routes directly and show they hold only ciphertext and opaque tokens.

Every route here speaks bytes and opaque labels only. Byte fields
travel as base64 inside JSON (HTTP/JSON is text-first; base64 is just
a transport encoding, not a cryptographic step -- it adds no
confidentiality). No route parses, tokenizes, or interprets what any
of those bytes mean, and none of them import client.crypto or
client.keymgmt.

Scope history: Phase 2 added storage only -- /index stored and
returned individual label -> value rows (a raw dictionary primitive)
with no search loop. Phase 4 adds that loop: POST /search runs
Section 06's "regenerate labels from a client-supplied K1, stop at
the first miss" algorithm via run_search_loop() below, using
storage.get_index_entry() for each step -- the exact primitive Phase 2
built and earmarked for this.

run_search_loop() and its two small helpers (_cloud_prf,
_counter_to_bytes) reimplement HMAC-SHA256 and the counter encoding
locally with the stdlib, rather than importing client.crypto /
client.indexer. That import boundary stays intentionally sharp even
though HMAC-SHA256 itself is public, standard cryptography -- what
must never cross it is the trusted client's actual key-management
code and vault secrets, not the mere ability to compute a hash. See
tests/test_integration.py's cross-implementation check for how the
two independent implementations are kept from silently drifting apart
instead of relying on a shared import.
"""

from __future__ import annotations

import base64
import hashlib
import hmac as _hmac_module
import os

from flask import Flask, jsonify, request

from . import storage

DEFAULT_DB_PATH = os.environ.get("VAULT_DB_PATH", "vault.sqlite3")


def _b64(value: bytes) -> str:
    return base64.b64encode(value).decode("ascii")


def _unb64(value: str, field: str) -> bytes:
    if not isinstance(value, str):
        raise ValueError(f"field {field!r} must be a base64 string")
    try:
        return base64.b64decode(value, validate=True)
    except Exception as exc:  # malformed base64 -> a 400, not a 500 crash
        raise ValueError(f"field {field!r} is not valid base64") from exc


def _cloud_prf(key: bytes, data: bytes) -> bytes:
    """HMAC-SHA256(key, data) -- Section 06's F, recomputed here with
    the stdlib rather than imported from client.crypto.prf(). This is
    a deliberate duplication, not an oversight: cloud/ must never
    import client/ (the AST-based tests in tests/test_storage.py and
    tests/test_cloud_app.py enforce this), and HMAC-SHA256 is public,
    standard cryptography -- computing it here needs no secret this
    module doesn't already have from the caller. `key` is always a
    client-supplied, single-search, single-keyword token (K1), never a
    vault secret; this function has no way to obtain K_index, K_file,
    or the master key, and never receives them.

    Consistency with client/crypto.py's prf() is enforced by a test
    (tests/test_integration.py) that computes labels both ways for the
    same inputs and asserts they match byte-for-byte, rather than by
    sharing code -- see the module docstring for why.
    """
    return _hmac_module.new(key, data, hashlib.sha256).digest()


def _counter_to_bytes(counter: int) -> bytes:
    """Must exactly match client/indexer.py's counter_to_bytes(): an
    8-byte big-endian encoding. See _cloud_prf's docstring."""
    return counter.to_bytes(8, "big")


def run_search_loop(conn, k1: bytes) -> "list[bytes]":
    """Section 06's cloud-side search loop: regenerate labels with the
    caller-supplied K1 and stop at the first counter whose label is
    not in the index ("contiguous counters -> clean stop").

    Touches only `conn` and `k1` -- no other key, no plaintext, no
    state beyond what the caller explicitly handed it. Never decrypts
    anything; it only recognises which opaque rows exist.

    Defensive bound (not part of the documented protocol, added for
    robustness): a keyword can never legitimately have more postings
    than there are total rows in the whole sse_index table, because
    each hit consumes one distinct row and rows aren't shared between
    keywords. So looping more than (total row count + 1) times without
    a miss is structurally impossible for honest data -- reaching it
    means a corrupted index or a bug, not a real search result, and is
    reported as such rather than looping forever.
    """
    total_entries = storage.index_entry_count(conn)
    results: "list[bytes]" = []
    counter = 0
    while True:
        if counter > total_entries:
            raise RuntimeError(
                f"search loop exceeded the total indexed entry count "
                f"({total_entries}) without a miss -- this should be "
                f"structurally impossible and indicates a corrupted "
                f"index or a bug, not a legitimate search result"
            )
        label = _cloud_prf(k1, _counter_to_bytes(counter)).hex()
        value = storage.get_index_entry(conn, label)
        if value is None:
            return results
        results.append(value)
        counter += 1


def create_app(db_path: str = DEFAULT_DB_PATH) -> Flask:
    app = Flask(__name__)
    app.config["DB_PATH"] = db_path
    # Touch the DB once at startup so the schema exists before the
    # first request, rather than failing (or racing) on it.
    storage.connect(db_path).close()

    # -- health --------------------------------------------------------

    @app.get("/health")
    def health():
        return jsonify({"status": "ok", "role": "untrusted-cloud"})

    # -- documents -------------------------------------------------------

    @app.post("/documents")
    def upload_document():
        body = request.get_json(silent=True) or {}
        doc_id = body.get("doc_id")
        if not isinstance(doc_id, str) or doc_id == "":
            return jsonify({"error": "doc_id must be a non-empty string"}), 400

        required = ("enc_name", "nonce", "ciphertext", "tag")
        missing = [f for f in required if f not in body]
        if missing:
            return jsonify({"error": f"missing fields: {missing}"}), 400

        try:
            fields = {f: _unb64(body[f], f) for f in required}
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

        try:
            with storage.open_db(app.config["DB_PATH"]) as conn:
                storage.save_document(conn, doc_id=doc_id, **fields)
        except storage.DuplicateDocumentError as exc:
            return jsonify({"error": str(exc)}), 409

        return jsonify({"doc_id": doc_id}), 201

    @app.get("/documents")
    def list_documents_route():
        with storage.open_db(app.config["DB_PATH"]) as conn:
            docs = storage.list_documents(conn)
        return jsonify(
            [
                {
                    "doc_id": d["doc_id"],
                    "enc_name": _b64(d["enc_name"]),
                    "size": d["size"],
                    "uploaded_at": d["uploaded_at"],
                }
                for d in docs
            ]
        )

    @app.get("/documents/<doc_id>")
    def get_document_route(doc_id: str):
        try:
            with storage.open_db(app.config["DB_PATH"]) as conn:
                doc = storage.get_document(conn, doc_id)
        except storage.DocumentNotFoundError:
            return jsonify({"error": "not found"}), 404
        return jsonify(
            {
                "doc_id": doc["doc_id"],
                "enc_name": _b64(doc["enc_name"]),
                "nonce": _b64(doc["nonce"]),
                "ciphertext": _b64(doc["ciphertext"]),
                "tag": _b64(doc["tag"]),
                "size": doc["size"],
                "uploaded_at": doc["uploaded_at"],
            }
        )

    @app.put("/documents/<doc_id>")
    def replace_document_route(doc_id: str):
        """In-place overwrite of an EXISTING document's encrypted
        fields, added for password/key rotation -- see
        cloud/storage.py's replace_document() docstring for why this is
        deliberately a separate route from POST /documents rather than
        that route upserting."""
        body = request.get_json(silent=True) or {}
        required = ("enc_name", "nonce", "ciphertext", "tag")
        missing = [f for f in required if f not in body]
        if missing:
            return jsonify({"error": f"missing fields: {missing}"}), 400

        try:
            fields = {f: _unb64(body[f], f) for f in required}
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

        with storage.open_db(app.config["DB_PATH"]) as conn:
            replaced = storage.replace_document(conn, doc_id=doc_id, **fields)
        if not replaced:
            return jsonify({"error": "not found"}), 404
        return jsonify({"doc_id": doc_id, "status": "replaced"}), 200

    @app.delete("/documents/<doc_id>")
    def delete_document_route(doc_id: str):
        with storage.open_db(app.config["DB_PATH"]) as conn:
            deleted = storage.delete_document(conn, doc_id)
        if not deleted:
            return jsonify({"error": "not found"}), 404
        return jsonify({"doc_id": doc_id, "status": "deleted"}), 200

    # -- sse_index ---------------------------------------------------------

    @app.post("/index")
    def push_index_entries():
        body = request.get_json(silent=True) or {}
        entries = body.get("entries")
        if not isinstance(entries, list) or not entries:
            return jsonify({"error": "'entries' must be a non-empty list"}), 400

        parsed = []
        for e in entries:
            if not isinstance(e, dict) or "label" not in e or "value" not in e:
                return jsonify({"error": "each entry needs 'label' and 'value'"}), 400
            label = e["label"]
            if not isinstance(label, str) or label == "":
                return jsonify({"error": "'label' must be a non-empty string"}), 400
            try:
                parsed.append((label, _unb64(e["value"], "value")))
            except ValueError as exc:
                return jsonify({"error": str(exc)}), 400

        try:
            with storage.open_db(app.config["DB_PATH"]) as conn:
                inserted = storage.save_index_entries(conn, parsed)
        except Exception as exc:  # sqlite3.IntegrityError on a label collision
            return jsonify({"error": str(exc)}), 409

        return jsonify({"inserted": inserted}), 201

    @app.get("/index/<label>")
    def get_index_entry_route(label: str):
        with storage.open_db(app.config["DB_PATH"]) as conn:
            value = storage.get_index_entry(conn, label)
        if value is None:
            return jsonify({"error": "not found"}), 404
        return jsonify({"label": label, "value": _b64(value)})

    @app.post("/index/replace")
    def replace_index_route():
        # Distinct from POST /index (Phase 2, unchanged): that route
        # is additive-insert-only and requires a non-empty list.
        # Rebuilding the whole index (Phase 5's upload flow) needs to
        # atomically REPLACE the table's contents -- including
        # correctly ending up empty if the corpus currently has zero
        # keywords -- so it gets its own route rather than changing
        # /index's established semantics.
        body = request.get_json(silent=True) or {}
        entries = body.get("entries")
        if not isinstance(entries, list):
            return jsonify({"error": "'entries' must be a list (may be empty)"}), 400

        parsed = []
        for e in entries:
            if not isinstance(e, dict) or "label" not in e or "value" not in e:
                return jsonify({"error": "each entry needs 'label' and 'value'"}), 400
            label = e["label"]
            if not isinstance(label, str) or label == "":
                return jsonify({"error": "'label' must be a non-empty string"}), 400
            try:
                parsed.append((label, _unb64(e["value"], "value")))
            except ValueError as exc:
                return jsonify({"error": str(exc)}), 400

        with storage.open_db(app.config["DB_PATH"]) as conn:
            removed = storage.clear_index(conn)
            inserted = storage.save_index_entries(conn, parsed) if parsed else 0

        return jsonify({"removed": removed, "inserted": inserted}), 200

    @app.post("/search")
    def search_route():
        body = request.get_json(silent=True) or {}
        if "k1" not in body:
            return jsonify({"error": "missing field: k1"}), 400
        try:
            k1 = _unb64(body["k1"], "k1")
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400

        with storage.open_db(app.config["DB_PATH"]) as conn:
            results = run_search_loop(conn, k1)

        return jsonify({"results": [_b64(v) for v in results], "count": len(results)}), 200

    # -- meta ----------------------------------------------------------------

    @app.post("/meta/<key>")
    def set_meta_route(key: str):
        body = request.get_json(silent=True) or {}
        if "value" not in body:
            return jsonify({"error": "missing field: value"}), 400
        try:
            value = _unb64(body["value"], "value")
        except ValueError as exc:
            return jsonify({"error": str(exc)}), 400
        with storage.open_db(app.config["DB_PATH"]) as conn:
            storage.set_meta(conn, key, value)
        return jsonify({"key": key}), 200

    @app.get("/meta/<key>")
    def get_meta_route(key: str):
        with storage.open_db(app.config["DB_PATH"]) as conn:
            value = storage.get_meta(conn, key)
        if value is None:
            return jsonify({"error": "not found"}), 404
        return jsonify({"key": key, "value": _b64(value)})

    return app


if __name__ == "__main__":
    # Runs the untrusted cloud on its own port, deliberately different
    # from the (future) trusted client app -- Section 02's "why two
    # processes matters for marks".
    create_app().run(port=5001, debug=False)
